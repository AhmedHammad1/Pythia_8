<html>
<head>
<title>PYTHIA 8 online manual</title>
<link rel="stylesheet" type="text/css" href="pythia.css"/>
<link rel="shortcut icon" href="pythia32.gif"/>
</head>
  
<frameset cols="260,*" framespacing="0" frameborder="0" border="0"> 
<frame src="Index.php" name="index" scrolling="auto" border="0" 
  marginwidth="20" marginheight="20" frameborder="0"> 
</frame> 
<frame src="Frontpage.php" name="page" scrolling="auto" border="0" 
  marginwidth="20" marginheight="20" frameborder="0"> 
</frame> 
</frameset> 
 
</html>
 
<!-- Copyright (C) 2014 Torbjorn Sjostrand --> 
